import React from 'react';
import {View, Text} from 'react-native';

import HomePage from './src/pages/HomePage'

const App = () => {

return (

<HomePage />

  ); 

}

export default App;